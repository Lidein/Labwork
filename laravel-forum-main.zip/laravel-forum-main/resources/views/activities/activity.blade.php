<div class="card mb-3">
    <div class="card-header">
        <div class="level">
            {{ $heading }}
        </div>
    </div>

    <div class="card-body">
        {{ $body }}
    </div>
</div>
