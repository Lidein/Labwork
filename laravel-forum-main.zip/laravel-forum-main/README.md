## Учебный пример форума на php-фреймворке Laravel

О процессе создания форума можно почитать на сайте [phpnick.ru](https://phpnick.ru/posts/category/php/43).
